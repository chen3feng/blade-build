extern "C" {
namespace binary_version {
extern const char kBuildType[] = "release";
extern const char kBuildTime[] = "Wed Mar 28 17:47:52 2012";
extern const char kBuilderName[] = "michaelpeng";
extern const char kHostName[] = "TengDa_10_6_222_128";
extern const char kCompiler[] = "GCC 4.5.1";
}
}
