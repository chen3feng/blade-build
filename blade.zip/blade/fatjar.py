# Copyright (c) 2016 Tencent Inc.
# All rights reserved.
#
# Author: Li Wenting <wentingli@tencent.com>
# Date:   April 14, 2016

"""

This is the fatjar module which packages multiple jar files
into a single fatjar file.

"""

import os
import sys
import time
import zipfile
import blade_util
import console


_JAR_MANIFEST = 'META-INF/MANIFEST.MF'
_FATJAR_EXCLUSIONS = frozenset(['LICENSE', 'README', 'NOTICE',
                                'META-INF/LICENSE', 'META-INF/README',
                                'META-INF/NOTICE', 'META-INF/INDEX.LIST'])


def _is_signature_file(name):
    parts = name.upper().split('/')
    if len(parts) == 2:
        for suffix in ('.SF', '.DSA', '.RSA'):
            if parts[1].endswith(suffix):
                return True
        if parts[1].startswith('SIG-'):
            return True
    return False


def _is_fat_jar_excluded(name):
    name = name.upper()
    for exclusion in _FATJAR_EXCLUSIONS:
        if name.startswith(exclusion):
            return True

    return name == _JAR_MANIFEST or _is_signature_file(name)


def _manifest_scm(build_dir):
    revision, url = blade_util.load_scm(build_dir)
    return [
        'SCM-Url: %s' % url,
        'SCM-Revision: %s' % revision,
    ]


def generate_fat_jar(target, jars):
    """Generate a fat jar containing the contents of all the jar dependencies. """
    target_dir = os.path.dirname(target)
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    target_fat_jar = zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED)
    # Record paths written in the fat jar to avoid duplicate writing
    path_jar_dict = {}
    conflict_logs = []

    for dep_jar in jars:
        jar = zipfile.ZipFile(dep_jar, 'r')
        name_list = jar.namelist()
        for name in name_list:
            if name.endswith('/') or not _is_fat_jar_excluded(name):
                if name not in path_jar_dict:
                    target_fat_jar.writestr(name, jar.read(name))
                    path_jar_dict[name] = os.path.basename(dep_jar)
                else:
                    if name.endswith('/'):
                        continue
                    message = ('%s: duplicated path %s found in {%s, %s}' % (
                        target, name, path_jar_dict[name],
                        os.path.basename(dep_jar)))
                    # Always log all conflicts for diagnosis
                    console.debug(message)
                    if '/.m2/repository/' not in dep_jar:
                        # There are too many conflicts between maven jars,
                        # so we have to ignore them, only count source code conflicts
                        conflict_logs.append(message)
        jar.close()

    if conflict_logs:
        log = '%s: Found %d conflicts when packaging.' % (target, len(conflict_logs))
        console.warning(log)

    # TODO(wentingli): Create manifest from dependency jars later if needed
    contents = [
        'Manifest-Version: 1.0',
        'Created-By: Python.Zipfile (Blade)',
        'Built-By: %s' % os.getenv('USER'),
        'Build-Time: %s' % time.asctime(),
    ]
    contents += _manifest_scm(target.split(os.sep)[0])
    contents.append('\n')
    target_fat_jar.writestr(_JAR_MANIFEST, '\n'.join(contents))
    target_fat_jar.close()


if __name__ == '__main__':
    generate_fat_jar(sys.argv[1], sys.argv[2:])
