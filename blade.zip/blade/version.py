VERSION=r'''("version" branch), 2019-03-16 3b2ad0d, by CHEN Feng'''
