
from cc_targets import *

# special rules for MEMO project
def memo_auto( name, srcs=[], **kwargs ):
    name = name
    if not srcs:
        if name.endswith('.c') or name.endswith('.cpp'):
            srcs = name
            name = name.replace('.cpp', '').replace('.c', '')
    return cc_library( name, srcs=srcs, **kwargs )

def memo_binary( name, srcs=[], **kwargs ):
    name = name
    if not srcs:
        if name.endswith('.c') or name.endswith('.cpp'):
            srcs = name
            name = name.replace('.cpp', '').replace('.c', '')
    return cc_binary( name, srcs=srcs, **kwargs )

def memo_cgi( name, **kwargs ):
    return memo_binary( name, extra_linkflags='-shared -z defs', **kwargs )

def memo_server( name, srcs=[], **kwargs ):
    return memo_binary( name, srcs=srcs, extra_linkflags='-z defs -fPIC -shared', **kwargs )
